export const POLICIES=[
    {'id':1,'type':'free','title':'Free Shipment'},
    {'id':2,'type':'standard','title':'Standard Shipment'},
    {'id':3,'type':'custom','title':'Custom Shipment'}
]